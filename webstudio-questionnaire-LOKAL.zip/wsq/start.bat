@echo off
chcp 65001 >nul
title WebStudio Questionnaire
cd /d "%~dp0"
where py >nul 2>nul && (py -3 server.py & goto :eof)
where python >nul 2>nul && (python server.py & goto :eof)
echo.
echo Python не найден. Два варианта:
echo  1. Установите Python с python.org (галочка "Add to PATH") и запустите start.bat снова.
echo  2. Либо просто откройте файл index.html двойным щелчком —
echo     приложение работает и так, но без оффлайн-режима PWA.
echo.
pause
