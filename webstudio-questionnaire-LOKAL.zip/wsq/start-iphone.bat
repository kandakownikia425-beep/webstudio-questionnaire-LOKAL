@echo off
chcp 65001 >nul
title WebStudio Questionnaire (iPhone)
cd /d "%~dp0"
echo Запуск для доступа с iPhone по Wi-Fi...
where py >nul 2>nul && (py -3 server.py --lan & goto :eof)
where python >nul 2>nul && (python server.py --lan & goto :eof)
echo Python не найден. Установите Python с python.org (галочка "Add to PATH").
pause
