// admin.js — административная панель: авторизация, дашборд, анкеты, импорт, бэкапы, настройки.
import * as db from './db.js';
import { STAGES, STATUSES, SITE_TYPES, DEFAULT_CONSENT_TEXT, getSiteType, getStatus } from './schema.js';
import {
  visibleStages, visibleQuestions, displayValue, progress, buildSummary, summaryToText, logHistory, fullReportText,
} from './logic.js';
import {
  esc, fmtDate, fmtSize, nowISO, uuid, toast, confirmDialog, hashPassword, verifyPassword, downloadBlob, copyText,
} from './util.js';
import { barChart, donutChart, lineChart } from './charts.js';
import { exportJSON, exportZIP, parseImportFile, applyImport, createBackup, restoreBackup } from './export.js';
import { themeButton } from './theme.js';

const authed = () => sessionStorage.getItem('wsq_admin') === '1';

// ───────────────────────── Вход и первый запуск ─────────────────────────
export async function renderAdmin(app, hash) {
  const adminRec = await db.getSetting('admin');
  if (!adminRec) return renderSetup(app);
  if (!authed()) return renderLogin(app);

  const route = hash.replace(/^#\/admin\/?/, '');
  if (route.startsWith('q/')) return layout(app, 'list', el => renderCard(el, route.slice(2)));
  if (route.startsWith('summary/')) return layout(app, 'list', el => renderSummary(el, route.slice(8)));
  if (route === 'list') return layout(app, 'list', renderList);
  if (route === 'import') return layout(app, 'import', renderImport);
  if (route === 'backup') return layout(app, 'backup', renderBackup);
  if (route === 'settings') return layout(app, 'settings', renderSettings);
  return layout(app, 'dash', renderDashboard);
}

function authScreen(app, title, subtitle, formHTML) {
  app.className = 'container';
  app.innerHTML = `
    <div class="topbar"><div class="brand"><div class="logo">W</div> WebStudio Questionnaire</div>
      <div class="nav-actions"></div></div>
    <div class="card" style="max-width:420px;margin:60px auto 0">
      <h2>${title}</h2>
      <p class="muted" style="margin:8px 0 18px">${subtitle}</p>
      ${formHTML}
    </div>
    <p style="text-align:center;margin-top:20px"><a class="dim" href="#/">← К анкете</a></p>`;
  app.querySelector('.nav-actions').appendChild(themeButton());
}

async function renderSetup(app) {
  authScreen(app, 'Настройка администратора',
    'Первый запуск: создайте пароль для доступа к административной панели. Пароль хранится только в виде защищённого хеша на этом устройстве.',
    `<div class="field"><label class="q-label">Пароль (не менее 6 символов)</label>
       <input class="input" type="password" id="pw1" autocomplete="new-password"></div>
     <div class="field"><label class="q-label">Повторите пароль</label>
       <input class="input" type="password" id="pw2" autocomplete="new-password"></div>
     <button class="btn btn-primary" id="go" style="width:100%">Создать администратора</button>`);
  app.querySelector('#go').onclick = async () => {
    const p1 = app.querySelector('#pw1').value, p2 = app.querySelector('#pw2').value;
    if (p1.length < 6) return toast('Пароль должен быть не короче 6 символов', 'error');
    if (p1 !== p2) return toast('Пароли не совпадают', 'error');
    const rec = await hashPassword(p1);
    await db.setSetting('admin', { ...rec, created_at: nowISO() });
    sessionStorage.setItem('wsq_admin', '1');
    toast('Администратор создан', 'success');
    location.hash = '#/admin';
    renderAdmin(app, '#/admin');
  };
}

async function renderLogin(app) {
  authScreen(app, 'Вход для администратора', 'Введите пароль, чтобы открыть панель управления анкетами.',
    `<div class="field"><label class="q-label">Пароль</label>
       <input class="input" type="password" id="pw" autocomplete="current-password" data-enter-submit="1"></div>
     <button class="btn btn-primary" id="go" style="width:100%">Войти</button>`);
  const tryLogin = async () => {
    const rec = await db.getSetting('admin');
    const ok = await verifyPassword(app.querySelector('#pw').value, rec);
    if (!ok) return toast('Неверный пароль', 'error');
    sessionStorage.setItem('wsq_admin', '1');
    renderAdmin(app, location.hash);
  };
  app.querySelector('#go').onclick = tryLogin;
  app.querySelector('#pw').onkeydown = e => { if (e.key === 'Enter') tryLogin(); };
}

// ───────────────────────── Каркас панели ─────────────────────────
const NAV = [
  ['dash', '#/admin', '📊', 'Дашборд'],
  ['list', '#/admin/list', '📋', 'Анкеты'],
  ['import', '#/admin/import', '📥', 'Импорт'],
  ['backup', '#/admin/backup', '💾', 'Резервные копии'],
  ['settings', '#/admin/settings', '⚙️', 'Настройки'],
];

async function layout(app, active, content) {
  app.className = '';
  app.innerHTML = `
    <div class="admin-layout">
      <aside class="sidebar no-print">
        <div class="brand"><div class="logo">W</div><span class="side-title">Questionnaire</span></div>
        ${NAV.map(([id, href, ic, lbl]) =>
          `<a class="navlink ${id === active ? 'on' : ''}" href="${href}">${ic} <span>${lbl}</span></a>`).join('')}
        <div style="flex:1"></div>
        <a class="navlink" href="#/" id="nav-exit-client">🏠 <span>К анкете</span></a>
        <a class="navlink" id="nav-logout">🚪 <span>Выйти</span></a>
      </aside>
      <main class="admin-main"><div id="admin-content"></div></main>
    </div>`;
  app.querySelector('#nav-logout').onclick = () => {
    sessionStorage.removeItem('wsq_admin');
    location.hash = '#/admin';
    renderAdmin(app, '#/admin');
  };
  await content(app.querySelector('#admin-content'));
}

function pageHeader(el, title, actionsHTML = '', backHref = null) {
  el.insertAdjacentHTML('beforeend', `
    <div class="topbar" style="padding-top:0">
      <div class="topbar-left">
        ${backHref ? `<a class="btn btn-ghost btn-icon no-print" href="${backHref}" aria-label="Назад" title="Назад">←</a>` : ''}
        <h1>${title}</h1>
      </div>
      <div class="nav-actions no-print">${actionsHTML}</div>
    </div>`);
  el.querySelector('.nav-actions').appendChild(themeButton());
}

// ───────────────────────── Дашборд ─────────────────────────
async function renderDashboard(el) {
  const all = await db.getAllQuestionnaires();
  pageHeader(el, 'Дашборд');

  const by = (fn) => all.reduce((m, q) => { const k = fn(q); m[k] = (m[k] || 0) + 1; return m; }, {});
  const byStatus = by(q => q.status);
  const newCount = (byStatus.completed || 0); // завершённые клиентом, но ещё не «отправлена/в работе»
  const stat = (num, lbl) => `<div class="card stat"><div class="num">${num}</div><div class="lbl">${lbl}</div></div>`;

  el.insertAdjacentHTML('beforeend', `
    <div class="statgrid">
      ${stat(all.length, 'Всего анкет')}
      ${stat(byStatus.completed || 0, 'Завершённые')}
      ${stat((byStatus.draft || 0) + (byStatus.progress || 0), 'В работе у клиентов')}
      ${stat(byStatus.sent || 0, 'Отправленные')}
      ${stat(byStatus.archived || 0, 'В архиве')}
    </div>
    <div id="recent"></div>
    <div class="chartgrid">
      <div class="card"><h3 style="margin-bottom:12px">Распределение по статусам</h3><div id="ch-status"></div></div>
      <div class="card"><h3 style="margin-bottom:12px">Анкеты по типам сайтов</h3><div id="ch-types"></div></div>
      <div class="card" style="grid-column:1/-1"><h3 style="margin-bottom:12px">Динамика поступления (30 дней)</h3><div id="ch-line"></div></div>
    </div>`);

  const fresh = all.filter(q => q.status === 'completed')
    .sort((x, y) => (y.completed_at || '').localeCompare(x.completed_at || '')).slice(0, 5);
  if (fresh.length) {
    const box = document.createElement('div');
    box.className = 'card';
    box.style.marginBottom = '14px';
    box.innerHTML = `<h3 style="margin-bottom:6px">Новые анкеты — ждут обработки (${byStatus.completed})</h3>`;
    for (const q of fresh) {
      const a = q.answers || {};
      const type = getSiteType(a.site_type);
      const r = document.createElement('div');
      r.className = 'recent-row';
      r.innerHTML = `<span class="rt">${esc(a.company_name || a.contact_name || 'Без названия')}</span>
        <span class="dim">${type ? esc(type.label) : ''} · ${fmtDate(q.completed_at)}</span>`;
      r.onclick = () => location.hash = '#/admin/q/' + q.id;
      box.appendChild(r);
    }
    el.querySelector('#recent').appendChild(box);
  }

  const statusColors = { draft: '#8a91a0', progress: '#2563eb', completed: '#16a34a', sent: '#7c3aed', archived: '#6b7280' };
  const donut = donutChart(STATUSES.map(s => ({ label: s.label, value: byStatus[s.id] || 0, color: statusColors[s.id] })));
  el.querySelector('#ch-status').appendChild(donut.el);

  const byType = by(q => q.answers?.site_type || '_none');
  el.querySelector('#ch-types').appendChild(barChart(
    SITE_TYPES.map(t => ({ label: t.label, value: byType[t.id] || 0 }))
      .concat(byType._none ? [{ label: 'Тип не выбран', value: byType._none }] : [])
  ));

  // динамика за 30 дней
  const days = [];
  for (let i = 29; i >= 0; i--) {
    const d = new Date(); d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    days.push({ key, label: `${d.getDate()}.${String(d.getMonth() + 1).padStart(2, '0')}`, value: 0 });
  }
  for (const q of all) {
    const k = (q.created_at || '').slice(0, 10);
    const day = days.find(d => d.key === k);
    if (day) day.value++;
  }
  el.querySelector('#ch-line').appendChild(lineChart(days));

  if (!all.length) {
    el.insertAdjacentHTML('beforeend', `<div class="card" style="margin-top:14px;text-align:center;padding:30px">
      <p class="muted">Анкет пока нет. Отправьте клиенту ссылку на приложение или <a href="#/">заполните анкету</a> вместе с ним.</p></div>`);
  }
}

// ───────────────────────── Список анкет ─────────────────────────
async function renderList(el) {
  const all = await db.getAllQuestionnaires();
  pageHeader(el, 'Анкеты', '', '#/admin');
  el.insertAdjacentHTML('beforeend', `
    <div class="filters no-print">
      <input class="input" id="f-search" placeholder="Поиск: компания, имя, телефон…">
      <select class="input" id="f-type"><option value="">Все типы</option>
        ${SITE_TYPES.map(t => `<option value="${t.id}">${t.label}</option>`).join('')}</select>
      <select class="input" id="f-status"><option value="">Все статусы</option>
        ${STATUSES.map(s => `<option value="${s.id}">${s.label}</option>`).join('')}</select>
      <select class="input" id="f-budget"><option value="">Любой бюджет</option>
        <option value="<10">До 10 т.</option><option value="10-20">10–20 т.</option>
        <option value="20-35">20–35 т.</option><option value="35-50">35–50 т.</option>
        <option value="50-100">50–100 т.</option><option value="100+">100 т.+</option>
        <option value="tbd">Не определён</option><option value="offer">Ждёт предложение</option></select>
      <label class="datefield"><span>Создана с</span><input class="input" id="f-from" type="date"></label>
      <label class="datefield"><span>Создана по</span><input class="input" id="f-to" type="date"></label>
      <select class="input" id="f-sort">
        <option value="new">Сначала новые</option><option value="old">Сначала старые</option>
        <option value="name">По названию</option></select>
      <button class="btn btn-ghost btn-sm" id="f-reset" style="align-self:flex-end">Сбросить</button>
    </div>
    <div class="selbar card no-print" id="selbar" hidden>
      <b id="selcount"></b>
      <button class="btn btn-ghost btn-sm" id="sel-all">Выбрать все показанные</button>
      <button class="btn btn-ghost btn-sm" id="sel-archive">В архив</button>
      <button class="btn btn-ghost btn-sm" id="sel-zip">Экспорт ZIP</button>
      <button class="btn btn-danger btn-sm" id="sel-del">Удалить</button>
      <button class="btn btn-ghost btn-sm" id="sel-clear">Снять выбор</button>
    </div>
    <div class="qlist" id="rows"></div>
    <p class="dim" id="count" style="margin-top:10px"></p>`);

  const rowsEl = el.querySelector('#rows');
  const selected = new Set();
  let shown = [];
  const refresh = async () => { el.innerHTML = ''; await renderList(el); };
  const updateBar = () => {
    const bar = el.querySelector('#selbar');
    bar.hidden = selected.size === 0;
    el.querySelector('#selcount').textContent = `Выбрано: ${selected.size}`;
  };
  const deleteMany = async (ids) => {
    const one = ids.length === 1 ? all.find(x => x.id === ids[0]) : null;
    const title = one ? 'Удалить анкету?' : `Удалить анкет: ${ids.length}?`;
    const text = one
      ? `Анкета «${one.answers?.company_name || one.answers?.contact_name || 'без названия'}» и все её файлы будут удалены безвозвратно. Рекомендуем сначала сделать экспорт или резервную копию.`
      : `Выбранные анкеты (${ids.length} шт.) и все их файлы будут удалены безвозвратно. Рекомендуем сначала сделать резервную копию.`;
    if (!(await confirmDialog(title, text, { okLabel: 'Удалить навсегда', danger: true }))) return;
    for (const id of ids) await db.deleteQuestionnaire(id);
    toast(ids.length === 1 ? 'Анкета удалена' : `Удалено анкет: ${ids.length}`, 'info');
    await refresh();
  };
  el.querySelector('#sel-all').onclick = () => {
    shown.forEach(q => selected.add(q.id));
    rowsEl.querySelectorAll('.qrow').forEach(r => { r.classList.add('sel'); const c = r.querySelector('.rowchk'); if (c) c.checked = true; });
    updateBar();
  };
  el.querySelector('#sel-clear').onclick = () => {
    selected.clear();
    rowsEl.querySelectorAll('.qrow').forEach(r => { r.classList.remove('sel'); const c = r.querySelector('.rowchk'); if (c) c.checked = false; });
    updateBar();
  };
  el.querySelector('#sel-del').onclick = () => deleteMany([...selected]);
  el.querySelector('#sel-zip').onclick = async () => {
    const qs = all.filter(q => selected.has(q.id));
    await exportZIP(qs);
    toast(`Выгружено анкет: ${qs.length}`, 'success');
  };
  el.querySelector('#sel-archive').onclick = async () => {
    for (const q of all.filter(x => selected.has(x.id))) {
      q.status = 'archived'; q.updated_at = nowISO();
      logHistory(q, 'Анкета перенесена в архив (массовое действие)');
      await db.putQuestionnaire(q);
    }
    toast(`В архив: ${selected.size}`, 'success');
    await refresh();
  };
  el.querySelector('#f-reset').onclick = () => {
    el.querySelectorAll('.filters .input').forEach(i => { i.value = i.tagName === 'SELECT' && i.id === 'f-sort' ? 'new' : ''; });
    apply();
  };
  const apply = () => {
    const s = el.querySelector('#f-search').value.trim().toLowerCase();
    const ft = el.querySelector('#f-type').value;
    const fs = el.querySelector('#f-status').value;
    const fb = el.querySelector('#f-budget').value;
    const from = el.querySelector('#f-from').value;
    const to = el.querySelector('#f-to').value;
    const sort = el.querySelector('#f-sort').value;

    let list = all.filter(q => {
      const a = q.answers || {};
      if (ft && a.site_type !== ft) return false;
      if (fs && q.status !== fs) return false;
      if (fb && a.budget !== fb) return false;
      const d = (q.created_at || '').slice(0, 10);
      if (from && d < from) return false;
      if (to && d > to) return false;
      if (s) {
        const hay = [a.company_name, a.brand_name, a.contact_name, a.contact_phone, a.contact_email, a.city, a.industry]
          .filter(Boolean).join(' ').toLowerCase();
        if (!hay.includes(s)) return false;
      }
      return true;
    });
    list.sort((x, y) => sort === 'old' ? (x.created_at || '').localeCompare(y.created_at || '')
      : sort === 'name' ? String(x.answers?.company_name || 'я').localeCompare(String(y.answers?.company_name || 'я'), 'ru')
      : (y.updated_at || '').localeCompare(x.updated_at || ''));

    rowsEl.innerHTML = '';
    shown = list;
    if (!list.length) {
      rowsEl.innerHTML = `<div class="card empty"><div class="big">${all.length ? '🔍' : '📭'}</div>
        ${all.length ? 'Ничего не найдено — измените или сбросьте фильтры' : 'Анкет пока нет'}</div>`;
    }
    for (const q of list) {
      const a = q.answers || {};
      const st = getStatus(q.status);
      const type = getSiteType(a.site_type);
      const p = progress(q);
      const row = document.createElement('div');
      row.className = 'card qrow' + (selected.has(q.id) ? ' sel' : '');
      row.innerHTML = `
        <input type="checkbox" class="rowchk" aria-label="Выбрать" ${selected.has(q.id) ? 'checked' : ''}>
        <div class="qmain">
          <div class="qtitle">${esc(a.company_name || a.contact_name || 'Без названия')}</div>
          <div class="qsub">${type ? type.icon + ' ' + esc(type.label) + ' · ' : ''}${fmtDate(q.updated_at)} · ${p.percent}% · ${esc(a.contact_phone || a.contact_email || '')}</div>
        </div>
        <span class="badge badge-${st.color}">${st.label}</span>
        <button class="btn btn-ghost btn-icon btn-sm row-del" title="Удалить анкету" aria-label="Удалить">🗑</button>`;
      const chk = row.querySelector('.rowchk');
      chk.onclick = e => e.stopPropagation();
      chk.onchange = () => {
        chk.checked ? selected.add(q.id) : selected.delete(q.id);
        row.classList.toggle('sel', chk.checked);
        updateBar();
      };
      row.querySelector('.row-del').onclick = async (e) => {
        e.stopPropagation();
        await deleteMany([q.id]);
      };
      row.onclick = () => location.hash = '#/admin/q/' + q.id;
      rowsEl.appendChild(row);
    }
    updateBar();
    el.querySelector('#count').textContent = `Показано: ${list.length} из ${all.length}`;
  };
  el.querySelectorAll('.filters .input').forEach(i => i.addEventListener('input', apply));
  apply();
}

// ───────────────────────── Карточка анкеты ─────────────────────────
async function renderCard(el, id) {
  const q = await db.getQuestionnaire(id);
  if (!q) { el.innerHTML = '<div class="card"><p>Анкета не найдена.</p><a href="#/admin/list">← К списку</a></div>'; return; }
  const a = q.answers || {};
  const st = getStatus(q.status);
  const type = getSiteType(a.site_type);
  const p = progress(q);

  pageHeader(el, esc(a.company_name || a.contact_name || 'Анкета'), '', '#/admin/list');

  el.insertAdjacentHTML('beforeend', `
    <div class="card" style="margin-bottom:14px">
      <div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-bottom:12px">
        <span class="badge badge-${st.color}">${st.label}</span>
        ${type ? `<span class="badge badge-gray">${type.icon} ${esc(type.label)}</span>` : ''}
        <span class="badge badge-gray">Заполнено ${p.percent}%</span>
        <span class="dim">Создана ${fmtDate(q.created_at)} · изменена ${fmtDate(q.updated_at)}${q.completed_at ? ' · завершена ' + fmtDate(q.completed_at) : ''}</span>
      </div>
      <div class="kv">
        <div class="k">Контакт</div><div class="v">${esc(a.contact_name || '—')} ${a.contact_company ? '(' + esc(a.contact_company) + ')' : ''}</div>
        <div class="k">Телефон</div><div class="v">${a.contact_phone ? `<a href="tel:${esc(a.contact_phone)}">${esc(a.contact_phone)}</a>` : '—'}</div>
        <div class="k">Telegram / Email</div><div class="v">${esc([a.contact_telegram, a.contact_email].filter(Boolean).join(' · ') || '—')}</div>
        <div class="k">Бюджет / сроки</div><div class="v">${esc([labelOf('budget', a.budget), labelOf('deadline', a.deadline)].filter(Boolean).join(' · ') || '—')}</div>
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:16px" class="no-print">
        <a class="btn btn-primary btn-sm" href="#/admin/summary/${q.id}">📄 Сводка</a>
        <button class="btn btn-ghost btn-sm" id="b-copy">📋 Копировать весь итог</button>
        <button class="btn btn-ghost btn-sm" id="b-json">Экспорт JSON</button>
        <button class="btn btn-ghost btn-sm" id="b-zip">Экспорт ZIP (с файлами)</button>
        <a class="btn btn-ghost btn-sm" href="#/survey/${q.id}">✏️ Редактировать ответы</a>
        <button class="btn btn-ghost btn-sm" id="b-archive">${q.status === 'archived' ? 'Вернуть из архива' : 'В архив'}</button>
        <button class="btn btn-danger btn-sm" id="b-del">Удалить</button>
      </div>
      <div style="display:flex;gap:8px;align-items:center;margin-top:14px" class="no-print">
        <span class="dim">Статус:</span>
        <select class="input" id="status-sel" style="width:auto;padding:7px 32px 7px 12px">
          ${STATUSES.map(s => `<option value="${s.id}" ${s.id === q.status ? 'selected' : ''}>${s.label}</option>`).join('')}
        </select>
      </div>
    </div>

    <div class="card" style="margin-bottom:14px">
      <h3 style="margin-bottom:10px">Заметки администратора</h3>
      <div id="notes"></div>
      <div style="display:flex;gap:8px;margin-top:10px" class="no-print">
        <input class="input" id="note-inp" placeholder="Новая заметка…">
        <button class="btn btn-primary" id="note-add">Добавить</button>
      </div>
    </div>

    <div class="card" style="margin-bottom:14px">
      <h3 style="margin-bottom:10px">Файлы клиента (${(q.fileRefs || []).length})</h3>
      <div class="filelist" id="files">${(q.fileRefs || []).length ? '' : '<span class="dim">Файлы не прикреплялись</span>'}</div>
    </div>

    <div id="answers"></div>

    <div class="card" style="margin-top:14px">
      <h3 style="margin-bottom:10px">История изменений</h3>
      <div id="history" class="dim" style="font-size:13px"></div>
    </div>`);

  // статус
  el.querySelector('#status-sel').onchange = async (e) => {
    const old = getStatus(q.status).label;
    q.status = e.target.value;
    q.updated_at = nowISO();
    logHistory(q, `Статус изменён: ${old} → ${getStatus(q.status).label}`);
    await db.putQuestionnaire(q);
    toast('Статус обновлён', 'success');
    renderAdminRefresh(el, id);
  };

  // действия
  el.querySelector('#b-copy').onclick = async () => {
    (await copyText(fullReportText(q))) ? toast('Весь итог скопирован', 'success') : toast('Не удалось скопировать', 'error');
  };
  el.querySelector('#b-json').onclick = async () => { await exportJSON([q]); toast('JSON выгружен', 'success'); markSent(q); };
  el.querySelector('#b-zip').onclick = async () => { await exportZIP([q]); toast('ZIP выгружен', 'success'); markSent(q); };
  el.querySelector('#b-archive').onclick = async () => {
    q.status = q.status === 'archived' ? 'completed' : 'archived';
    q.updated_at = nowISO();
    logHistory(q, q.status === 'archived' ? 'Анкета перенесена в архив' : 'Анкета возвращена из архива');
    await db.putQuestionnaire(q);
    renderAdminRefresh(el, id);
  };
  el.querySelector('#b-del').onclick = async () => {
    const ok = await confirmDialog('Удалить анкету?',
      `Анкета «${a.company_name || 'без названия'}» и все её файлы будут удалены безвозвратно. Рекомендуем сначала сделать экспорт.`,
      { okLabel: 'Удалить навсегда', danger: true });
    if (!ok) return;
    await db.deleteQuestionnaire(q.id);
    toast('Анкета удалена', 'info');
    location.hash = '#/admin/list';
  };

  // заметки
  const notesEl = el.querySelector('#notes');
  const drawNotes = () => {
    notesEl.innerHTML = (q.notes || []).length
      ? q.notes.map(n => `<div class="note">${esc(n.text)}<div class="dim">${fmtDate(n.created_at)}
          <button class="fdel no-print" data-id="${n.id}" style="float:right">✕</button></div></div>`).join('')
      : '<span class="dim">Заметок нет</span>';
    notesEl.querySelectorAll('.fdel').forEach(b => b.onclick = async () => {
      q.notes = q.notes.filter(n => n.id !== b.dataset.id);
      await db.putQuestionnaire(q);
      drawNotes();
    });
  };
  drawNotes();
  el.querySelector('#note-add').onclick = async () => {
    const inp = el.querySelector('#note-inp');
    if (!inp.value.trim()) return;
    q.notes = q.notes || [];
    q.notes.push({ id: uuid(), text: inp.value.trim(), created_at: nowISO() });
    q.updated_at = nowISO();
    await db.putQuestionnaire(q);
    inp.value = '';
    drawNotes();
    toast('Заметка добавлена', 'success');
  };

  // файлы
  const filesEl = el.querySelector('#files');
  for (const ref of q.fileRefs || []) {
    const item = document.createElement('div');
    item.className = 'fileitem';
    item.innerHTML = `<span>📄</span><span class="fname">${esc(ref.name)}</span>
      <span class="dim">${fmtSize(ref.size)}${ref.missing ? ' · нет содержимого (импорт из JSON)' : ''}</span>
      ${ref.missing ? '' : '<button class="btn btn-ghost btn-sm">Скачать</button>'}`;
    const btn = item.querySelector('button');
    if (btn) btn.onclick = async () => {
      const rec = await db.getFile(ref.id);
      if (rec?.blob) downloadBlob(rec.blob, ref.name);
      else toast('Содержимое файла недоступно', 'error');
    };
    filesEl.appendChild(item);
  }

  // ответы по этапам
  const ansEl = el.querySelector('#answers');
  for (const stg of visibleStages(q)) {
    let rows = '';
    for (const question of visibleQuestions(stg, q)) {
      const v = displayValue(question, a[question.id], q);
      rows += `<div class="k">${esc(question.label)}</div>
        <div class="v">${v == null ? '<span class="dim">—</span>' : Array.isArray(v) ? esc(v.join('\n')) : esc(v)}</div>`;
    }
    ansEl.insertAdjacentHTML('beforeend', `
      <div class="card section-block"><h3>${stg.icon} ${esc(stg.title)}</h3><div class="kv">${rows}</div></div>`);
  }

  // история
  el.querySelector('#history').innerHTML = (q.history || []).slice().reverse()
    .map(h => `${fmtDate(h.at)} — ${esc(h.event)}`).join('<br>') || 'Пусто';
}

function renderAdminRefresh(el, id) {
  // мягкая перерисовка карточки
  const content = document.getElementById('admin-content');
  if (content) { content.innerHTML = ''; renderCard(content, id); }
}

async function markSent(q) {
  if (q.status === 'completed') {
    q.status = 'sent';
    q.updated_at = nowISO();
    logHistory(q, 'Анкета экспортирована (помечена как отправленная)');
    await db.putQuestionnaire(q);
  }
}

function labelOf(qid, val) {
  if (!val) return null;
  for (const st of STAGES) {
    const question = st.questions.find(x => x.id === qid);
    if (question?.options && Array.isArray(question.options)) {
      return question.options.find(o => o.id === val)?.label || val;
    }
  }
  return val;
}

// ───────────────────────── Сводка ─────────────────────────
async function renderSummary(el, id) {
  const q = await db.getQuestionnaire(id);
  if (!q) { el.innerHTML = '<div class="card">Анкета не найдена.</div>'; return; }
  const sections = buildSummary(q);

  pageHeader(el, 'Сводка по клиенту', '', `#/admin/q/${q.id}`);
  el.insertAdjacentHTML('beforeend', `
    <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:14px" class="no-print">
      <button class="btn btn-primary btn-sm" id="s-pdf">🖨️ Печать / Сохранить в PDF</button>
      <button class="btn btn-ghost btn-sm" id="s-copy">Копировать сводку</button>
      <button class="btn btn-ghost btn-sm" id="s-copyall">📋 Копировать весь итог</button>
      <button class="btn btn-ghost btn-sm" id="s-json">Экспорт JSON</button>
      <button class="btn btn-ghost btn-sm" id="s-zip">Экспорт ZIP</button>
    </div>
    <div class="card" id="sum">
      <h2 style="margin-bottom:4px">${esc(q.answers?.company_name || 'Клиент')}</h2>
      <p class="dim" style="margin-bottom:16px">Сводка сформирована ${fmtDate(nowISO())} · WebStudio Questionnaire</p>
      ${sections.map(s => `
        <div class="section-block"><h3>${esc(s.title)}</h3><div class="kv">
          ${s.items.map(it => `<div class="k">${esc(it.label)}</div>
            <div class="v">${Array.isArray(it.value) ? esc(it.value.join('\n')) : esc(it.value)}</div>`).join('')}
        </div></div>`).join('')}
    </div>`);

  el.querySelector('#s-pdf').onclick = () => window.print();
  el.querySelector('#s-copy').onclick = async () => {
    (await copyText(summaryToText(q))) ? toast('Сводка скопирована', 'success') : toast('Не удалось скопировать автоматически', 'error');
  };
  el.querySelector('#s-copyall').onclick = async () => {
    (await copyText(fullReportText(q))) ? toast('Весь итог скопирован', 'success') : toast('Не удалось скопировать автоматически', 'error');
  };
  el.querySelector('#s-json').onclick = () => exportJSON([q]).then(() => toast('JSON выгружен', 'success'));
  el.querySelector('#s-zip').onclick = () => exportZIP([q]).then(() => toast('ZIP выгружен', 'success'));
}

// ───────────────────────── Импорт ─────────────────────────
async function renderImport(el) {
  pageHeader(el, 'Импорт анкет', '', '#/admin');
  el.insertAdjacentHTML('beforeend', `
    <div class="card">
      <p class="muted" style="margin-bottom:14px">Загрузите файл обмена — <b>JSON</b> (только данные) или <b>ZIP</b> (данные + прикреплённые файлы),
      созданный WebStudio Questionnaire на другом устройстве или WebStudio OS Local.</p>
      <div class="dropzone" id="dz">📥 Нажмите, чтобы выбрать файл для импорта<br><span class="dim">.json или .zip</span></div>
      <input type="file" id="fi" accept=".json,.zip" hidden>
      <div id="preview" style="margin-top:16px"></div>
    </div>`);

  const fi = el.querySelector('#fi');
  el.querySelector('#dz').onclick = () => fi.click();
  fi.onchange = async () => {
    const file = fi.files[0];
    if (!file) return;
    const prev = el.querySelector('#preview');
    prev.innerHTML = '<p class="dim">Проверка файла…</p>';
    const parsed = await parseImportFile(file);
    if (!parsed.ok) {
      prev.innerHTML = `<div class="note" style="background:var(--red-soft)">
        <b>Импорт невозможен:</b><br>${parsed.errors.map(esc).join('<br>')}</div>`;
      return;
    }
    const decisions = new Map();
    prev.innerHTML = `
      <p class="muted">Файл корректен: формат <b>${esc(parsed.meta.format)}</b> v${parsed.meta.version},
        выгружен ${fmtDate(parsed.meta.exported_at)}. Анкет: <b>${parsed.items.length}</b>.</p>
      <div id="items" style="margin-top:10px"></div>
      <button class="btn btn-primary" id="apply" style="margin-top:14px">Импортировать</button>`;
    const itemsEl = prev.querySelector('#items');
    for (const item of parsed.items) {
      const a = item.record.answers || {};
      const dup = !!item.existing;
      if (dup) decisions.set(item.record.id, 'skip');
      const row = document.createElement('div');
      row.className = 'fileitem';
      row.style.marginBottom = '6px';
      row.innerHTML = `
        <span>${dup ? '⚠️' : '🆕'}</span>
        <span class="fname">${esc(a.company_name || a.contact_name || item.record.id.slice(0, 8))}
          <span class="dim">· ${getStatus(item.record.status).label} · файлов: ${item.filesAvailable}/${item.filesCount}</span></span>
        ${dup ? `<select class="input" style="width:auto;padding:6px 30px 6px 10px;font-size:13px">
            <option value="skip">Пропустить (дубликат)</option>
            <option value="overwrite">Перезаписать существующую</option>
            <option value="copy">Импортировать как копию</option>
          </select>` : '<span class="badge badge-green">Новая</span>'}`;
      const sel = row.querySelector('select');
      if (sel) sel.onchange = () => decisions.set(item.record.id, sel.value);
      itemsEl.appendChild(row);
    }
    prev.querySelector('#apply').onclick = async () => {
      const hasOverwrite = [...decisions.values()].includes('overwrite');
      if (hasOverwrite) {
        const ok = await confirmDialog('Перезаписать данные?',
          'Некоторые существующие анкеты будут заменены данными из файла. Это действие необратимо.',
          { okLabel: 'Перезаписать', danger: true });
        if (!ok) return;
      }
      try {
        const res = await applyImport(parsed, decisions);
        toast(`Импортировано: ${res.imported}, перезаписано: ${res.overwritten}, пропущено: ${res.skipped}`, 'success', 5000);
        prev.innerHTML = '';
        fi.value = '';
      } catch (err) {
        toast('Ошибка импорта: ' + err.message, 'error', 6000);
      }
    };
  };
}

// ───────────────────────── Резервные копии ─────────────────────────
async function renderBackup(el) {
  pageHeader(el, 'Резервные копии', '', '#/admin');
  const all = await db.getAllQuestionnaires();
  el.insertAdjacentHTML('beforeend', `
    <div class="card" style="margin-bottom:14px">
      <h3>Создать резервную копию</h3>
      <p class="muted" style="margin:8px 0 14px">В копию входят все анкеты (${all.length} шт.), прикреплённые файлы и настройки.
      Файл сохранится в загрузки — перенесите его в надёжное место.</p>
      <button class="btn btn-primary" id="mk">💾 Создать копию (.zip)</button>
    </div>
    <div class="card">
      <h3>Восстановить из копии</h3>
      <p class="muted" style="margin:8px 0 6px">Восстановление <b>заменит все текущие данные</b> содержимым копии.</p>
      <p class="muted" style="margin:0 0 14px">Перед заменой автоматически скачается страховочная копия текущих данных.</p>
      <button class="btn btn-ghost" id="rs">♻️ Выбрать файл копии…</button>
      <input type="file" id="rsf" accept=".zip,.json" hidden>
    </div>
    <div class="card" style="margin-top:14px">
      <h3>Совет для iPhone</h3>
      <p class="muted" style="margin-top:8px">iOS может очищать данные браузера при нехватке места. Регулярно создавайте копию
      и сохраняйте её в «Файлы» или отправляйте себе — так анкеты не потеряются.</p>
    </div>`);

  el.querySelector('#mk').onclick = async () => {
    try {
      const res = await createBackup();
      toast(`Копия создана: ${res.name} (анкет: ${res.count}, файлов: ${res.files})`, 'success', 5000);
    } catch (err) { toast('Ошибка: ' + err.message, 'error', 6000); }
  };
  const rsf = el.querySelector('#rsf');
  el.querySelector('#rs').onclick = () => rsf.click();
  rsf.onchange = async () => {
    const file = rsf.files[0];
    if (!file) return;
    const ok = await confirmDialog('Восстановить из копии?',
      'Все текущие анкеты и файлы будут заменены данными из копии. Страховочная копия текущих данных скачается автоматически.',
      { okLabel: 'Восстановить', danger: true });
    if (!ok) { rsf.value = ''; return; }
    try {
      const res = await restoreBackup(file);
      toast(`Восстановлено анкет: ${res.restored}`, 'success', 5000);
      location.hash = '#/admin';
    } catch (err) {
      toast('Восстановление не выполнено: ' + err.message, 'error', 7000);
    }
    rsf.value = '';
  };
}

// ───────────────────────── Настройки ─────────────────────────
async function renderSettings(el) {
  pageHeader(el, 'Настройки', '', '#/admin');
  const consent = await db.getSetting('consent_text') || DEFAULT_CONSENT_TEXT;
  el.insertAdjacentHTML('beforeend', `
    <div class="card" style="margin-bottom:14px">
      <h3>Смена пароля администратора</h3>
      <div class="field" style="margin-top:12px"><label class="q-label">Текущий пароль</label>
        <input class="input" type="password" id="p-old"></div>
      <div class="field"><label class="q-label">Новый пароль (не менее 6 символов)</label>
        <input class="input" type="password" id="p-new"></div>
      <button class="btn btn-primary" id="p-save">Сменить пароль</button>
    </div>
    <div class="card" style="margin-bottom:14px">
      <h3>Текст согласия на обработку данных</h3>
      <p class="dim" style="margin:6px 0 10px">Показывается клиенту на последнем шаге анкеты. Текст не является юридически
      проверенным документом — при необходимости согласуйте формулировку с юристом.</p>
      <textarea class="input" id="c-text" style="min-height:120px">${esc(consent)}</textarea>
      <div style="display:flex;gap:8px;margin-top:10px">
        <button class="btn btn-primary btn-sm" id="c-save">Сохранить</button>
        <button class="btn btn-ghost btn-sm" id="c-reset">Вернуть стандартный</button>
      </div>
    </div>
    <div class="card">
      <h3>Экспорт всех анкет</h3>
      <p class="muted" style="margin:8px 0 12px">Выгрузка всех анкет одним файлом — для переноса в WebStudio OS Local или на другое устройство.</p>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button class="btn btn-ghost btn-sm" id="e-json">Все анкеты → JSON</button>
        <button class="btn btn-ghost btn-sm" id="e-zip">Все анкеты → ZIP (с файлами)</button>
      </div>
    </div>`);

  el.querySelector('#p-save').onclick = async () => {
    const rec = await db.getSetting('admin');
    if (!(await verifyPassword(el.querySelector('#p-old').value, rec))) return toast('Текущий пароль неверен', 'error');
    const np = el.querySelector('#p-new').value;
    if (np.length < 6) return toast('Новый пароль слишком короткий', 'error');
    const newRec = await hashPassword(np);
    await db.setSetting('admin', { ...newRec, created_at: rec.created_at, updated_at: nowISO() });
    toast('Пароль изменён', 'success');
    el.querySelector('#p-old').value = el.querySelector('#p-new').value = '';
  };
  el.querySelector('#c-save').onclick = async () => {
    await db.setSetting('consent_text', el.querySelector('#c-text').value.trim());
    toast('Текст согласия сохранён', 'success');
  };
  el.querySelector('#c-reset').onclick = async () => {
    await db.setSetting('consent_text', null);
    el.querySelector('#c-text').value = DEFAULT_CONSENT_TEXT;
    toast('Возвращён стандартный текст', 'info');
  };
  el.querySelector('#e-json').onclick = async () => exportJSON(await db.getAllQuestionnaires()).then(() => toast('JSON выгружен', 'success'));
  el.querySelector('#e-zip').onclick = async () => exportZIP(await db.getAllQuestionnaires()).then(() => toast('ZIP выгружен', 'success'));
}
