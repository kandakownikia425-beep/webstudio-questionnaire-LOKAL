// export.js — экспорт/импорт анкет (JSON и ZIP), резервное копирование и восстановление.
// Формат обмена с WebStudio OS Local описан в docs/EXCHANGE_FORMAT.md.
import * as db from './db.js';
import { createZip, readZip } from './zip.js';
import {
  buildExchange, validateExchange, fromExchange, EXCHANGE_FORMAT,
} from './logic.js';
import { downloadBlob, nowISO, uuid } from './util.js';

const enc = new TextEncoder();
const dec = new TextDecoder();

function stamp() { return nowISO().slice(0, 19).replace(/[:T]/g, '-'); }

// ─────────────── Экспорт ───────────────
export async function exportJSON(qs) {
  const payload = buildExchange(qs);
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const name = qs.length === 1
    ? `anketa_${(qs[0].answers?.company_name || qs[0].id.slice(0, 8)).replace(/[^\wа-яА-ЯёЁ-]+/g, '_')}_${stamp()}.json`
    : `anketas_${qs.length}_${stamp()}.json`;
  downloadBlob(blob, name);
  return name;
}

export async function exportZIP(qs) {
  const payload = buildExchange(qs);
  const entries = [{ name: 'data.json', data: enc.encode(JSON.stringify(payload, null, 2)) }];
  for (const q of qs) {
    for (const ref of q.fileRefs || []) {
      const rec = await db.getFile(ref.id);
      if (rec && rec.blob) {
        const buf = new Uint8Array(await rec.blob.arrayBuffer());
        entries.push({ name: `files/${q.id}/${ref.id}_${ref.name}`, data: buf });
      }
    }
  }
  const zipBytes = createZip(entries);
  const blob = new Blob([zipBytes], { type: 'application/zip' });
  const name = qs.length === 1
    ? `anketa_${(qs[0].answers?.company_name || qs[0].id.slice(0, 8)).replace(/[^\wа-яА-ЯёЁ-]+/g, '_')}_${stamp()}.zip`
    : `backup_wsq_${stamp()}.zip`;
  downloadBlob(blob, name);
  return name;
}

// ─────────────── Импорт: разбор файла → предпросмотр ───────────────
/**
 * Разбирает файл (JSON или ZIP). Возвращает:
 * { ok, errors[], items: [{ record, existing, filesCount }], zipFiles: Map<'qid/fileId_name', Uint8Array> }
 */
export async function parseImportFile(file) {
  let json = null;
  const zipFiles = new Map();

  try {
    const bytes = new Uint8Array(await file.arrayBuffer());
    const isZip = bytes.length > 4 && bytes[0] === 0x50 && bytes[1] === 0x4b; // сигнатура "PK"
    if (isZip) {
      const entries = await readZip(bytes);
      const dataEntry = entries.find(e => e.name === 'data.json' || e.name.endsWith('/data.json'));
      if (!dataEntry) return { ok: false, errors: ['В архиве нет файла data.json.'] };
      json = JSON.parse(dec.decode(dataEntry.data));
      for (const e of entries) {
        const m = e.name.match(/^files\/([^/]+)\/(.+)$/);
        if (m) zipFiles.set(m[1] + '/' + m[2], e.data);
      }
    } else {
      json = JSON.parse(new TextDecoder().decode(bytes));
    }
  } catch (err) {
    return { ok: false, errors: ['Не удалось прочитать файл: ' + err.message] };
  }

  const v = validateExchange(json);
  if (!v.ok) return { ok: false, errors: v.errors };

  const items = [];
  for (const rec of json.questionnaires) {
    const record = fromExchange(rec);
    const existing = await db.getQuestionnaire(record.id);
    items.push({
      record,
      existing: existing || null,
      filesCount: (record.fileRefs || []).length,
      filesAvailable: (record.fileRefs || []).filter(f => zipFiles.has(record.id + '/' + f.id + '_' + f.name)).length,
    });
  }
  return {
    ok: true, errors: [], items, zipFiles,
    settings: json.settings || null,
    meta: { format: json.format, version: json.version, exported_at: json.exported_at },
  };
}

/**
 * Применить импорт. decisions: Map<id, 'skip'|'overwrite'|'copy'>.
 * Возвращает { imported, skipped, overwritten }.
 */
export async function applyImport(parsed, decisions) {
  let imported = 0, skipped = 0, overwritten = 0;
  for (const item of parsed.items) {
    const action = decisions.get(item.record.id) || (item.existing ? 'skip' : 'import');
    if (action === 'skip') { skipped++; continue; }
    let rec = item.record;
    if (action === 'copy') {
      const old = rec.id;
      rec = { ...rec, id: uuid(), fileRefs: (rec.fileRefs || []).map(f => ({ ...f })) };
      rec._origId = old;
    }
    if (action === 'overwrite' && item.existing) {
      // удалить старые файлы перезаписываемой анкеты
      const oldFiles = await db.getFilesByQ(rec.id);
      for (const f of oldFiles) await db.deleteFile(f.id);
      overwritten++;
    } else {
      imported++;
    }
    const srcId = rec._origId || rec.id;
    const keptRefs = [];
    for (const ref of rec.fileRefs || []) {
      const key = srcId + '/' + ref.id + '_' + ref.name;
      const data = parsed.zipFiles?.get(key);
      const newRef = { ...ref, id: action === 'copy' ? uuid() : ref.id, qid: ref.qid };
      if (data) {
        await db.putFile({ ...newRef, blob: new Blob([data], { type: ref.type || 'application/octet-stream' }) });
        keptRefs.push(newRef);
      } else {
        // файла в архиве нет (импорт из JSON) — сохраняем только описание
        keptRefs.push({ ...newRef, missing: true });
      }
    }
    delete rec._origId;
    rec.fileRefs = keptRefs;
    rec.history = rec.history || [];
    rec.history.push({ at: nowISO(), event: 'Импортирована из файла обмена' });
    await db.putQuestionnaire(rec);
  }
  return { imported, skipped, overwritten };
}

// ─────────────── Резервная копия (всё приложение) ───────────────
export async function createBackup() {
  const qs = await db.getAllQuestionnaires();
  const payload = buildExchange(qs);
  payload.backup = true;
  payload.settings = {
    consent_text: await db.getSetting('consent_text') || null,
  };
  const entries = [{ name: 'data.json', data: enc.encode(JSON.stringify(payload, null, 2)) }];
  const files = await db.getAllFiles();
  const qids = new Set(qs.map(q => q.id));
  for (const f of files) {
    if (!qids.has(f.qid) && !qs.some(q => (q.fileRefs || []).some(r => r.id === f.id))) continue;
    const owner = qs.find(q => (q.fileRefs || []).some(r => r.id === f.id));
    if (!owner || !f.blob) continue;
    entries.push({ name: `files/${owner.id}/${f.id}_${f.name}`, data: new Uint8Array(await f.blob.arrayBuffer()) });
  }
  const blob = new Blob([createZip(entries)], { type: 'application/zip' });
  const name = `wsq_backup_${stamp()}.zip`;
  downloadBlob(blob, name);
  return { name, count: qs.length, files: entries.length - 1 };
}

/**
 * Восстановление из резервной копии: перед заменой создаёт страховочную копию
 * текущих данных (скачивается автоматически), затем заменяет всё содержимое.
 */
export async function restoreBackup(file, { makeSafetyCopy = true } = {}) {
  const parsed = await parseImportFile(file);
  if (!parsed.ok) throw new Error(parsed.errors.join(' '));
  if (makeSafetyCopy) {
    const existing = await db.getAllQuestionnaires();
    if (existing.length) await createBackup(); // страховочная копия текущих данных
  }
  await db.clearAllData();
  // после очистки ни одной анкеты не существует — всё импортируется заново
  await applyImport(parsed, new Map(parsed.items.map(i => [i.record.id, 'overwrite'])));
  if (parsed.settings?.consent_text) {
    await db.setSetting('consent_text', parsed.settings.consent_text);
  }
  return { restored: parsed.items.length };
}
