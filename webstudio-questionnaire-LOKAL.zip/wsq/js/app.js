// app.js — точка входа: тема, маршрутизация, регистрация service worker.
import { requestPersistence, getSetting, setSetting } from './db.js';
import { renderHome, renderSurvey, renderReview, renderDone } from './survey.js';
import { renderAdmin } from './admin.js';
import { toast } from './util.js';
import { initKeyboardHelper } from './keyboard.js';
import { initTheme } from './theme.js';

// ---------- Маршрутизация ----------
async function route() {
  const hash = location.hash || '#/';
  const app = document.getElementById('app');
  app.className = hash.startsWith('#/admin') ? '' : 'container';
  window.scrollTo(0, 0);
  try {
    if (hash.startsWith('#/survey/')) await renderSurvey(app, hash.split('/')[2]);
    else if (hash.startsWith('#/review/')) await renderReview(app, hash.split('/')[2]);
    else if (hash.startsWith('#/done')) await renderDone(app);
    else if (hash.startsWith('#/admin')) await renderAdmin(app, hash);
    else await renderHome(app);
  } catch (err) {
    console.error(err);
    app.innerHTML = `<div class="card" style="margin-top:40px">
      <h2>Что-то пошло не так</h2>
      <p class="muted" style="margin:10px 0">${(err && err.message) || 'Неизвестная ошибка'}. Данные анкет не пострадали — они хранятся локально.</p>
      <a class="btn btn-primary" href="#/">На главную</a></div>`;
  }
}

window.addEventListener('hashchange', route);

// ---------- Запуск ----------
initTheme();
initKeyboardHelper();
requestPersistence();
route();

// Service worker — оффлайн-режим (работает по http/https, не по file://)
if ('serviceWorker' in navigator && location.protocol !== 'file:') {
  navigator.serviceWorker.register('sw.js').catch(() => {/* оффлайн-режим недоступен — не критично */});
}

// Глобальная защита: сообщаем о непойманных ошибках, не теряя данные
window.addEventListener('unhandledrejection', e => {
  console.error(e.reason);
  if (String(e.reason?.name) === 'QuotaExceededError') {
    toast('Недостаточно места в хранилище браузера. Удалите лишние файлы или сделайте резервную копию.', 'error', 6000);
  }
});
