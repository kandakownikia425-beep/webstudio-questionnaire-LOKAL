// logic.js — чистая логика опроса: условная видимость, прогресс, валидация,
// формирование сводки и формат обмена. Без DOM — тестируется в Node.

import { STAGES, SITE_TYPES, SCALES, SCHEMA_VERSION, getSiteType, getStatus } from './schema.js';
import { nowISO, uuid, fmtDate } from './util.js';

export const EXCHANGE_FORMAT = 'webstudio.questionnaire.exchange';
export const EXCHANGE_VERSION = 1;
export const APP_VERSION = '1.0.0';

// ---------- Активные типы анкеты ----------
export function activeTypes(q) {
  const a = q.answers || {};
  const set = new Set();
  if (a.site_type) set.add(a.site_type);
  for (const t of a.site_type_extra || []) set.add(t);
  return set;
}

// ---------- Проверка условий ----------
export function checkCond(cond, q) {
  if (!cond) return true;
  if (cond.all) return cond.all.every(c => checkCond(c, q));
  if (cond.any) return cond.any.some(c => checkCond(c, q));
  if (cond.type) return activeTypes(q).has(cond.type);
  if (cond.matrix) {
    const v = (q.answers || {})[cond.matrix];
    const cell = v && typeof v === 'object' ? v[cond.row] : undefined;
    return cond.in ? cond.in.includes(cell) : !!cell;
  }
  if (cond.q) {
    const v = (q.answers || {})[cond.q];
    if (cond.has !== undefined) {
      if (Array.isArray(v)) return v.includes(cond.has);
      return v === cond.has;
    }
    if (cond.notEmpty) return v != null && v !== '' && !(Array.isArray(v) && !v.length);
  }
  return true;
}

// ---------- Видимость ----------
export function visibleStages(q) {
  return STAGES.filter(st => checkCond(st.showIf, q));
}

export function visibleQuestions(stage, q) {
  return stage.questions.filter(question => checkCond(question.showIf, q));
}

// ---------- Прогресс ----------
export function progress(q) {
  const stages = visibleStages(q);
  let total = 0, answered = 0;
  for (const st of stages) {
    for (const question of visibleQuestions(st, q)) {
      if (question.type === 'consent') continue;
      total++;
      if (isAnswered(question, (q.answers || {})[question.id], q)) answered++;
    }
  }
  return { total, answered, percent: total ? Math.round(answered / total * 100) : 0 };
}

export function isAnswered(question, v, q) {
  if (question.type === 'files') return !!(q.fileRefs || []).some(f => f.qid === question.id);
  if (v == null) return false;
  if (Array.isArray(v)) return v.length > 0;
  if (typeof v === 'object') return Object.keys(v).length > 0;
  return String(v).trim() !== '';
}

// ---------- Валидация этапа ----------
export function validateStage(stage, q) {
  const errors = [];
  for (const question of visibleQuestions(stage, q)) {
    if (!question.required) continue;
    const v = (q.answers || {})[question.id];
    if (question.type === 'consent') {
      if (v !== true) errors.push({ id: question.id, msg: 'Нужно согласие на обработку данных' });
    } else if (!isAnswered(question, v, q)) {
      errors.push({ id: question.id, msg: 'Обязательное поле' });
    }
  }
  return errors;
}

// ---------- Новая анкета ----------
export function newQuestionnaire() {
  const ts = nowISO();
  return {
    id: uuid(),
    schema_version: SCHEMA_VERSION,
    created_at: ts,
    updated_at: ts,
    completed_at: null,
    status: 'draft',
    stage_index: 0,
    answers: {},
    fileRefs: [],   // [{id, qid, name, type, size}] — содержимое в хранилище файлов
    notes: [],      // [{id, text, created_at}]
    history: [],    // [{at, event}]
  };
}

export function logHistory(q, event) {
  q.history = q.history || [];
  q.history.push({ at: nowISO(), event });
  if (q.history.length > 200) q.history = q.history.slice(-200);
}

// ---------- Человекочитаемое значение ответа ----------
export function displayValue(question, v, q) {
  if (question.type === 'files') {
    const fs = (q.fileRefs || []).filter(f => f.qid === question.id);
    return fs.length ? fs.map(f => f.name).join(', ') : null;
  }
  if (v == null || v === '' || (Array.isArray(v) && !v.length)) return null;
  if (question.type === 'consent') return v === true ? 'Согласие получено' : null;
  if (question.type === 'typecards') {
    return getSiteType(v)?.label || String(v);
  }
  const optLabel = (id) => {
    if (question.options === 'SITE_TYPES_EXTRA') return getSiteType(id)?.label || id;
    const o = (question.options || []).find(o => o.id === id);
    return o ? o.label : id;
  };
  if (question.type === 'select') {
    if (v === '__other__') {
      const otherText = (q.answers || {})[question.id + '__other'];
      return otherText ? 'Другое: ' + otherText : 'Другое';
    }
    return optLabel(v);
  }
  if (question.type === 'multi') {
    const parts = v.filter(x => x !== '__other__').map(optLabel);
    const otherText = (q.answers || {})[question.id + '__other'];
    if (v.includes('__other__') && otherText) parts.push('Другое: ' + otherText);
    return parts.join(', ');
  }
  if (question.type === 'matrix') {
    const scale = SCALES[question.scale || 'P'];
    const lines = [];
    for (const row of question.rows) {
      const cell = v[row.id];
      if (!cell) continue;
      let lbl = scale.find(s => s.id === cell)?.label || cell;
      if (question.scaleLabels && question.scaleLabels[cell]) lbl = question.scaleLabels[cell];
      lines.push(`${row.label} — ${lbl}`);
    }
    return lines.length ? lines : null;
  }
  return String(v);
}

// ---------- Сводка ----------
const NA = 'Не указано';

export function buildSummary(q) {
  const a = q.answers || {};
  const typeLabel = getSiteType(q.answers?.site_type)?.label || NA;
  const extraLabels = (a.site_type_extra || []).map(t => getSiteType(t)?.label || t);

  const pick = id => {
    for (const st of STAGES) {
      const question = st.questions.find(x => x.id === id);
      if (question) {
        if (!checkCond(st.showIf, q) || !checkCond(question.showIf, q)) return null; // скрытые ветки не учитываются
        return displayValue(question, a[id], q);
      }
    }
    return null;
  };
  const line = (label, id) => ({ label, value: pick(id) ?? NA });

  // Разбор матриц по приоритетам
  const matrixByPriority = (qid, wanted) => {
    const st = STAGES.find(s => s.questions.some(x => x.id === qid));
    if (!st || !checkCond(st.showIf, q)) return [];
    const question = st.questions.find(x => x.id === qid);
    const v = a[qid] || {};
    return question.rows.filter(r => wanted.includes(v[r.id])).map(r => r.label);
  };

  const sections = [];
  const add = (title, items) => {
    const filtered = items.filter(Boolean);
    if (filtered.length) sections.push({ title, items: filtered });
  };

  add('1. Общая информация', [
    { label: 'Дата заполнения', value: fmtDate(q.completed_at || q.updated_at) },
    { label: 'Статус анкеты', value: getStatus(q.status).label },
  ]);
  add('2. Компания', [
    line('Название компании', 'company_name'), line('Бренд', 'brand_name'),
    line('Город / регион', 'city'), line('Территория работы', 'work_area'),
    line('Опыт работы', 'experience'), line('Сотрудники', 'employees'),
    line('Описание бизнеса', 'business_desc'),
    line('Преимущества', 'advantages'), line('Существующий сайт', 'current_site'),
    line('Конкуренты', 'competitors'),
  ]);
  add('3. Сфера деятельности', [
    line('Сфера', 'industry'), line('Направления', 'main_directions'),
    line('Товары и услуги', 'products_services'),
  ]);
  add('4. Целевая аудитория', [
    line('Аудитория', 'target_audience'), line('Основные клиенты', 'main_clients'),
    line('География клиентов', 'clients_geo'),
  ]);
  add('5. Цели сайта', [
    line('Цели', 'goals'), line('Как приходят клиенты сейчас', 'clients_now'),
    line('Проблемы сейчас', 'problems_now'), line('Ожидаемые изменения', 'expected_change'),
    line('Критерий успеха', 'success_criteria'), line('Важные показатели', 'kpi'),
  ]);
  add('6. Тип сайта', [
    { label: 'Основной тип', value: typeLabel },
    { label: 'Дополнительные направления', value: extraLabels.length ? extraLabels.join(', ') : NA },
    a.site_type === 'other' || (a.site_type_extra || []).includes('other')
      ? line('Описание проекта', 'site_type_other') : null,
  ]);
  add('7. Структура сайта', [
    { label: 'Обязательные разделы', value: matrixByPriority('sections', ['must']).join(', ') || NA },
    { label: 'Желательные разделы', value: matrixByPriority('sections', ['want']).join(', ') || NA },
    line('Другие разделы', 'sections_other'),
    line('Примерное число страниц', 'pages_count'),
    line('Кто будет обновлять сайт', 'who_updates'),
  ]);
  add('8. Пожелания по дизайну', [
    line('Стиль', 'style'),
    line('Основной цвет', 'color_primary'), line('Акценты', 'color_accent'),
    line('Нежелательные цвета', 'colors_avoid'), line('Тема', 'theme_pref'),
    line('Логотип', 'has_logo'), line('Фирменный стиль', 'has_brand'),
    line('Нравятся сайты', 'sites_like'), line('Не нравятся', 'sites_dislike'),
    line('Что нравится в примерах', 'like_what'), line('Референсы', 'design_refs'),
    line('Фотографии', 'photos_usage'),
  ]);
  add('9. Требуемая функциональность', [
    { label: 'Обязательно', value: matrixByPriority('features', ['must']).join(', ') || NA },
    { label: 'Желательно', value: matrixByPriority('features', ['want']).join(', ') || NA },
    line('CRM', 'crm_name'), line('Данные в CRM', 'crm_data'),
    line('Языки', 'langs'), line('Внешние сервисы', 'integrations_which'),
    line('Уведомления', 'notifications_how'), line('Другие функции', 'features_other'),
  ]);

  // Ветка выбранного типа
  const branchStages = STAGES.filter(s => s.branch && checkCond(s.showIf, q));
  for (const bs of branchStages) {
    const items = [];
    for (const question of visibleQuestions(bs, q)) {
      const val = displayValue(question, a[question.id], q);
      items.push({ label: question.label, value: val ?? NA });
    }
    add(`10. Детали: ${bs.title}`, items);
  }

  add('11. Контент и материалы', [
    { label: 'Готово', value: matrixByPriority('materials', ['ready']).join(', ') || NA },
    { label: 'Частично готово', value: matrixByPriority('materials', ['part']).join(', ') || NA },
    { label: 'Отсутствует', value: matrixByPriority('materials', ['none']).join(', ') || NA },
    { label: 'Нужна помощь', value: matrixByPriority('materials', ['help']).join(', ') || NA },
    line('Что подготовить', 'help_needed'),
    { label: 'Приложенные файлы', value: (q.fileRefs || []).map(f => f.name).join(', ') || NA },
  ]);
  add('12. Технические требования', [
    line('Домен', 'has_domain'), line('Адрес домена', 'domain_name'), line('Хостинг', 'has_hosting'),
    { label: 'Обязательно', value: matrixByPriority('tech_needs', ['must']).join(', ') || NA },
    { label: 'Желательно', value: matrixByPriority('tech_needs', ['want']).join(', ') || NA },
  ]);
  add('13. Интеграции', [
    line('Онлайн-оплата', 'payments_detail'), line('1С', '1c_detail'),
    line('Прочие интеграции', 'integration_details'),
  ]);
  add('14. Бюджет', [line('Бюджет', 'budget')]);
  add('15. Сроки', [line('Сроки', 'deadline'), line('Срочность', 'urgency')]);
  add('16. Контакты', [
    line('Имя', 'contact_name'), line('Компания', 'contact_company'),
    line('Телефон', 'contact_phone'), line('Telegram', 'contact_telegram'),
    line('Email', 'contact_email'), line('Способ связи', 'contact_pref'),
    line('Удобное время', 'contact_time'),
  ]);
  add('17. Дополнительные пожелания', [
    line('Комментарии', 'comments'), line('Доп. требования', 'extra_requirements'),
    line('Важно знать разработчику', 'dev_should_know'),
  ]);

  // 18. Что уточнить: собираем «Пока не знаю» и пустые обязательные зоны
  const clarify = [];
  for (const st of visibleStages(q)) {
    for (const question of visibleQuestions(st, q)) {
      if (question.type === 'matrix') {
        const v = a[question.id] || {};
        const dk = question.rows.filter(r => v[r.id] === 'dk').map(r => r.label);
        if (dk.length) clarify.push({ label: question.label, value: 'Клиент не определился: ' + dk.join(', ') });
      }
      if (question.type === 'select' && (a[question.id] === 'dk' || a[question.id] === 'tbd')) {
        clarify.push({ label: question.label, value: 'Требует уточнения' });
      }
    }
  }
  if (!pick('budget') || a.budget === 'tbd' || a.budget === 'offer') {
    clarify.push({ label: 'Бюджет', value: 'Согласовать с клиентом' });
  }
  add('18. Что уточнить перед началом разработки', clarify.length ? clarify : [{ label: '—', value: 'Критичных пробелов не выявлено' }]);

  return sections;
}

export function summaryToText(q) {
  const sections = buildSummary(q);
  const out = ['СВОДКА ПО АНКЕТЕ — WebStudio Questionnaire', ''];
  for (const s of sections) {
    out.push(s.title.toUpperCase());
    for (const it of s.items) {
      const val = Array.isArray(it.value) ? '\n    • ' + it.value.join('\n    • ') : it.value;
      out.push(`  ${it.label}: ${val}`);
    }
    out.push('');
  }
  return out.join('\n');
}

// ---------- Формат обмена с WebStudio OS Local ----------
export function buildExchange(questionnaires) {
  return {
    format: EXCHANGE_FORMAT,
    version: EXCHANGE_VERSION,
    exported_at: nowISO(),
    app: { name: 'WebStudio Questionnaire', version: APP_VERSION },
    questionnaires: questionnaires.map(q => ({
      id: q.id,
      schema_version: q.schema_version || SCHEMA_VERSION,
      created_at: q.created_at, updated_at: q.updated_at, completed_at: q.completed_at,
      status: q.status, stage_index: q.stage_index,
      answers: q.answers || {},
      files: (q.fileRefs || []).map(f => ({ id: f.id, qid: f.qid, name: f.name, type: f.type, size: f.size })),
      notes: q.notes || [], history: q.history || [],
    })),
  };
}

/** Проверка структуры импортируемого файла. Возвращает {ok, errors, data}. */
export function validateExchange(obj) {
  const errors = [];
  if (!obj || typeof obj !== 'object') errors.push('Файл не содержит данных JSON.');
  else {
    if (obj.format !== EXCHANGE_FORMAT) errors.push(`Неизвестный формат: «${obj.format || 'не указан'}». Ожидался ${EXCHANGE_FORMAT}.`);
    if (typeof obj.version !== 'number') errors.push('Не указана версия формата.');
    else if (obj.version > EXCHANGE_VERSION) errors.push(`Версия формата ${obj.version} новее поддерживаемой (${EXCHANGE_VERSION}). Обновите приложение.`);
    if (!Array.isArray(obj.questionnaires)) errors.push('Отсутствует список анкет (questionnaires).');
    else obj.questionnaires.forEach((q, i) => {
      if (!q.id) errors.push(`Анкета №${i + 1}: нет обязательного поля id.`);
      if (!q.created_at) errors.push(`Анкета №${i + 1}: нет обязательного поля created_at.`);
      if (q.answers == null || typeof q.answers !== 'object') errors.push(`Анкета №${i + 1}: нет блока ответов (answers).`);
    });
  }
  return { ok: errors.length === 0, errors, data: errors.length ? null : obj };
}

/** Привести импортированную запись к внутреннему виду. */
export function fromExchange(rec) {
  return {
    id: rec.id,
    schema_version: rec.schema_version || 1,
    created_at: rec.created_at,
    updated_at: rec.updated_at || rec.created_at,
    completed_at: rec.completed_at || null,
    status: ['draft', 'progress', 'completed', 'sent', 'archived'].includes(rec.status) ? rec.status : 'draft',
    stage_index: rec.stage_index || 0,
    answers: rec.answers || {},
    fileRefs: (rec.files || []).map(f => ({ id: f.id, qid: f.qid, name: f.name, type: f.type, size: f.size })),
    notes: rec.notes || [],
    history: rec.history || [],
  };
}

/** Весь итог одним текстом: шапка + ответы по всем активным этапам + файлы. */
export function fullReportText(q) {
  const a = q.answers || {};
  const out = [];
  out.push('АНКЕТА КЛИЕНТА — WebStudio Questionnaire');
  out.push(`Клиент: ${a.company_name || a.contact_name || NA}`);
  out.push(`Тип сайта: ${getSiteType(a.site_type)?.label || NA}`);
  out.push(`Статус: ${getStatus(q.status).label}`);
  out.push(`Создана: ${fmtDate(q.created_at)}${q.completed_at ? ' · Завершена: ' + fmtDate(q.completed_at) : ''}`);
  out.push('');
  for (const st of visibleStages(q)) {
    out.push(`=== ${st.title.toUpperCase()} ===`);
    for (const question of visibleQuestions(st, q)) {
      if (question.type === 'consent') continue;
      const v = displayValue(question, a[question.id], q);
      if (v == null) out.push(`${question.label}: ${NA}`);
      else if (Array.isArray(v)) out.push(`${question.label}:\n` + v.map(x => '  • ' + x).join('\n'));
      else out.push(`${question.label}: ${v}`);
    }
    out.push('');
  }
  if (a.consent === true) out.push('Согласие на обработку данных: получено');
  const fl = (q.fileRefs || []).map(f => f.name);
  out.push('Прикреплённые файлы: ' + (fl.length ? fl.join(', ') : NA));
  return out.join('\n');
}
