// theme.js — тема оформления (вынесено из app.js, чтобы не было циклических импортов)
export function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  try { localStorage.setItem('wsq_theme', theme); } catch (_) {}
}
export function initTheme() {
  let t = null;
  try { t = localStorage.getItem('wsq_theme'); } catch (_) {}
  if (!t) t = matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  applyTheme(t);
}
export function toggleTheme() {
  applyTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
}
export function themeButton() {
  const b = document.createElement('button');
  b.className = 'btn btn-ghost btn-icon no-print';
  b.title = 'Переключить тему';
  b.setAttribute('aria-label', 'Переключить тему');
  const icon = () => document.documentElement.dataset.theme === 'dark' ? '☀️' : '🌙';
  b.textContent = icon();
  b.onclick = () => { toggleTheme(); b.textContent = icon(); };
  return b;
}
