// util.js — общие помощники (работает в браузере и в Node для тестов)
export function uuid() {
  if (globalThis.crypto?.randomUUID) return crypto.randomUUID();
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

export function nowISO() { return new Date().toISOString(); }

export function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, m => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[m]));
}

export function fmtDate(iso, withTime = true) {
  if (!iso) return '—';
  const d = new Date(iso);
  if (isNaN(d)) return '—';
  const dd = String(d.getDate()).padStart(2, '0');
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const yy = d.getFullYear();
  if (!withTime) return `${dd}.${mm}.${yy}`;
  const hh = String(d.getHours()).padStart(2, '0');
  const mi = String(d.getMinutes()).padStart(2, '0');
  return `${dd}.${mm}.${yy} ${hh}:${mi}`;
}

export function fmtSize(bytes) {
  if (bytes == null) return '—';
  if (bytes < 1024) return bytes + ' Б';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' КБ';
  return (bytes / 1024 / 1024).toFixed(1) + ' МБ';
}

export function debounce(fn, ms) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

export function downloadBlob(blob, filename) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
}

// ---- Криптография паролей (WebCrypto, PBKDF2-SHA256) ----
const te = () => new TextEncoder();

// SHA-256 / PBKDF2-HMAC-SHA256 на чистом JS. Нужен, потому что Safari на iPhone при открытии
// по http:// (локальная сеть) отключает crypto.subtle. Результат идентичен WebCrypto.
const K256 = new Uint32Array([
  0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
  0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
  0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
  0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
  0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
  0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
  0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
  0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2,
]);
const H256 = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
const _W = new Uint32Array(64);

/** Один блок: state (8 слов) обновляется на месте; w — 16 слов блока. */
function sha256Block(state, w) {
  const W = _W;
  for (let i = 0; i < 16; i++) W[i] = w[i];
  for (let i = 16; i < 64; i++) {
    const a = W[i - 15], b = W[i - 2];
    const s0 = ((a >>> 7) | (a << 25)) ^ ((a >>> 18) | (a << 14)) ^ (a >>> 3);
    const s1 = ((b >>> 17) | (b << 15)) ^ ((b >>> 19) | (b << 13)) ^ (b >>> 10);
    W[i] = (W[i - 16] + s0 + W[i - 7] + s1) | 0;
  }
  let a = state[0], b = state[1], c = state[2], d = state[3], e = state[4], f = state[5], g = state[6], h = state[7];
  for (let i = 0; i < 64; i++) {
    const S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
    const ch = (e & f) ^ (~e & g);
    const t1 = (h + S1 + ch + K256[i] + W[i]) | 0;
    const S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
    const maj = (a & b) ^ (a & c) ^ (b & c);
    const t2 = (S0 + maj) | 0;
    h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
  }
  state[0] = (state[0] + a) | 0; state[1] = (state[1] + b) | 0; state[2] = (state[2] + c) | 0; state[3] = (state[3] + d) | 0;
  state[4] = (state[4] + e) | 0; state[5] = (state[5] + f) | 0; state[6] = (state[6] + g) | 0; state[7] = (state[7] + h) | 0;
}

/** Продолжить хеш с состояния state; prefixBytes — сколько байт уже обработано до него. Возвращает 8 слов. */
function sha256From(state0, msg, prefixBytes = 0) {
  const state = Int32Array.from(state0);
  const total = prefixBytes + msg.length;
  const padded = new Uint8Array(Math.ceil((msg.length + 9) / 64) * 64);
  padded.set(msg); padded[msg.length] = 0x80;
  const dv = new DataView(padded.buffer);
  dv.setUint32(padded.length - 4, (total * 8) >>> 0);
  dv.setUint32(padded.length - 8, Math.floor((total * 8) / 4294967296));
  const w = new Uint32Array(16);
  for (let off = 0; off < padded.length; off += 64) {
    for (let i = 0; i < 16; i++) w[i] = dv.getUint32(off + i * 4);
    sha256Block(state, w);
  }
  return state;
}

export function sha256Js(bytes) {
  const st = sha256From(H256, bytes, 0);
  const out = new Uint8Array(32), dv = new DataView(out.buffer);
  for (let i = 0; i < 8; i++) dv.setUint32(i * 4, st[i] >>> 0);
  return out;
}

export function pbkdf2Sha256Js(passwordBytes, salt, iterations) {
  let key = passwordBytes;
  if (key.length > 64) key = sha256Js(key);
  const ipad = new Uint8Array(64).fill(0x36), opad = new Uint8Array(64).fill(0x5c);
  for (let i = 0; i < key.length; i++) { ipad[i] ^= key[i]; opad[i] ^= key[i]; }
  const blockWords = (b) => { const dv = new DataView(b.buffer); const w = new Uint32Array(16); for (let i = 0; i < 16; i++) w[i] = dv.getUint32(i * 4); return w; };
  const istate = Int32Array.from(H256), ostate = Int32Array.from(H256);
  sha256Block(istate, blockWords(ipad));
  sha256Block(ostate, blockWords(opad));

  // U1 = HMAC(P, salt || INT(1))
  const first = new Uint8Array(salt.length + 4); first.set(salt); first[first.length - 1] = 1;
  const inner1 = sha256From(istate, first, 64);
  const outerMsg = new Uint8Array(32), odv = new DataView(outerMsg.buffer);
  for (let i = 0; i < 8; i++) odv.setUint32(i * 4, inner1[i] >>> 0);
  let u = sha256From(ostate, outerMsg, 64);
  const t = Int32Array.from(u);

  const w = new Uint32Array(16);
  const si = new Int32Array(8), so = new Int32Array(8);
  for (let n = 1; n < iterations; n++) {
    for (let i = 0; i < 8; i++) w[i] = u[i]; w[8] = 0x80000000; for (let i = 9; i < 15; i++) w[i] = 0; w[15] = 768;
    si.set(istate); sha256Block(si, w);
    for (let i = 0; i < 8; i++) w[i] = si[i]; w[8] = 0x80000000; for (let i = 9; i < 15; i++) w[i] = 0; w[15] = 768;
    so.set(ostate); sha256Block(so, w);
    for (let i = 0; i < 8; i++) { u[i] = so[i]; t[i] ^= so[i]; }
  }
  const out = new Uint8Array(32), dv = new DataView(out.buffer);
  for (let i = 0; i < 8; i++) dv.setUint32(i * 4, t[i] >>> 0);
  return out;
}

export async function hashPassword(password, saltB64 = null, iterations = 160000) {
  const salt = saltB64 ? b64ToBytes(saltB64) : crypto.getRandomValues(new Uint8Array(16));
  const pw = te().encode(password);
  let bits;
  if (globalThis.crypto?.subtle) {
    const key = await crypto.subtle.importKey('raw', pw, 'PBKDF2', false, ['deriveBits']);
    bits = new Uint8Array(await crypto.subtle.deriveBits(
      { name: 'PBKDF2', salt, iterations, hash: 'SHA-256' }, key, 256));
  } else {
    bits = pbkdf2Sha256Js(pw, salt, iterations);   // http:// без secure context
  }
  return { salt: bytesToB64(salt), hash: bytesToB64(bits), iterations };
}

export async function verifyPassword(password, rec) {
  const { hash } = await hashPassword(password, rec.salt, rec.iterations);
  return timingSafeEqual(hash, rec.hash);
}

function timingSafeEqual(a, b) {
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}

export function bytesToB64(bytes) {
  let bin = '';
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin);
}

export function b64ToBytes(b64) {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

// ---- Toast-уведомления ----
export function toast(msg, type = 'info', ms = 3200) {
  let host = document.getElementById('toasts');
  if (!host) {
    host = document.createElement('div');
    host.id = 'toasts';
    document.body.appendChild(host);
  }
  const el = document.createElement('div');
  el.className = 'toast toast-' + type;
  el.textContent = msg;
  host.appendChild(el);
  requestAnimationFrame(() => el.classList.add('show'));
  setTimeout(() => {
    el.classList.remove('show');
    setTimeout(() => el.remove(), 300);
  }, ms);
}

// ---- Модальное подтверждение ----
export function confirmDialog(title, text, { okLabel = 'Подтвердить', danger = false } = {}) {
  return new Promise(resolve => {
    const wrap = document.createElement('div');
    wrap.className = 'modal-backdrop';
    wrap.innerHTML = `
      <div class="modal" role="dialog" aria-modal="true">
        <h3>${esc(title)}</h3>
        <p>${esc(text)}</p>
        <div class="modal-actions">
          <button class="btn btn-ghost" data-act="cancel">Отмена</button>
          <button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" data-act="ok">${esc(okLabel)}</button>
        </div>
      </div>`;
    wrap.addEventListener('click', e => {
      if (e.target === wrap || e.target.dataset.act === 'cancel') { wrap.remove(); resolve(false); }
      if (e.target.dataset.act === 'ok') { wrap.remove(); resolve(true); }
    });
    document.body.appendChild(wrap);
  });
}

// ---- Навигация с историей: «назад» возвращается по истории, а не плодит записи ----
export function navTo(hash, from = null) {
  history.pushState({ wsqFrom: from }, '', hash);
  window.dispatchEvent(new HashChangeEvent('hashchange'));
}
/** Назад к экрану, из которого пришли (history.back); иначе обычный переход. */
export function navBack(targetFrom, fallbackHash, currentFrom = null) {
  if (history.state && history.state.wsqFrom === targetFrom) history.back();
  else navTo(fallbackHash, currentFrom);
}

/** Копирование текста в буфер обмена с запасным способом для iOS/Safari и file:// */
export async function copyText(text) {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch (_) { /* пробуем запасной способ */ }
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0;font-size:16px';
    document.body.appendChild(ta);
    ta.focus(); ta.select(); ta.setSelectionRange(0, text.length);
    const ok = document.execCommand('copy');
    ta.remove();
    return ok;
  } catch (_) { return false; }
}
