// Автотесты чистой логики: node tests/logic.test.mjs
import assert from 'node:assert/strict';
import { STAGES, SITE_TYPES, SCALES } from '../js/schema.js';
import {
  checkCond, visibleStages, visibleQuestions, validateStage, progress,
  newQuestionnaire, buildSummary, summaryToText, displayValue,
  buildExchange, validateExchange, fromExchange, EXCHANGE_FORMAT, EXCHANGE_VERSION, fullReportText,
} from '../js/logic.js';
import { createZip, readZip, crc32 } from '../js/zip.js';
import { pbkdf2Sha256Js, sha256Js, hashPassword, verifyPassword, bytesToB64 } from '../js/util.js';
import nodeCrypto from 'node:crypto';

let passed = 0, failed = 0;
const test = async (name, fn) => {
  try { await fn(); passed++; console.log('  ✓', name); }
  catch (e) { failed++; console.error('  ✗', name, '\n    ', e.message); }
};

console.log('— Целостность схемы —');
await test('ID вопросов уникальны по всей схеме', () => {
  const ids = new Set();
  for (const st of STAGES) for (const q of st.questions) {
    assert.ok(!ids.has(q.id), `дубликат id: ${q.id}`);
    ids.add(q.id);
  }
});
await test('9 типов сайтов, у 9 есть ветки', () => {
  assert.equal(SITE_TYPES.length, 9);
  const branches = STAGES.filter(s => s.branch).map(s => s.branch);
  assert.equal(new Set(branches).size, 9);
  for (const t of SITE_TYPES) assert.ok(branches.includes(t.id), `нет ветки для ${t.id}`);
});
await test('Матрицы ссылаются на существующие шкалы, строки уникальны', () => {
  for (const st of STAGES) for (const q of st.questions) {
    if (q.type !== 'matrix') continue;
    assert.ok(SCALES[q.scale || 'P'], `нет шкалы ${q.scale} у ${q.id}`);
    const rows = new Set(q.rows.map(r => r.id));
    assert.equal(rows.size, q.rows.length, `дубли строк в ${q.id}`);
  }
});
await test('Условия showIf ссылаются на существующие вопросы', () => {
  const ids = new Set();
  for (const st of STAGES) for (const q of st.questions) ids.add(q.id);
  const walk = (c, where) => {
    if (!c) return;
    if (c.q) assert.ok(ids.has(c.q), `showIf в ${where} ссылается на несуществующий ${c.q}`);
    if (c.matrix) assert.ok(ids.has(c.matrix), `showIf в ${where}: нет матрицы ${c.matrix}`);
    (c.all || []).forEach(x => walk(x, where));
    (c.any || []).forEach(x => walk(x, where));
  };
  for (const st of STAGES) {
    walk(st.showIf, 'этап ' + st.id);
    for (const q of st.questions) walk(q.showIf, q.id);
  }
});

console.log('— Условная логика —');
await test('Для магазина видна ветка магазина и скрыта ветка портфолио', () => {
  const q = newQuestionnaire();
  q.answers.site_type = 'shop';
  const ids = visibleStages(q).map(s => s.id);
  assert.ok(ids.includes('b_shop'));
  assert.ok(!ids.includes('b_portfolio'));
  assert.ok(!ids.includes('b_booking'));
});
await test('Дополнительное направление открывает вторую ветку', () => {
  const q = newQuestionnaire();
  q.answers.site_type = 'card';
  q.answers.site_type_extra = ['booking'];
  const ids = visibleStages(q).map(s => s.id);
  assert.ok(ids.includes('b_card') && ids.includes('b_booking'));
});
await test('Вопрос про CRM появляется только при выборе CRM в функциях', () => {
  const q = newQuestionnaire();
  q.answers.site_type = 'card';
  const stage = STAGES.find(s => s.id === 'features');
  let ids = visibleQuestions(stage, q).map(x => x.id);
  assert.ok(!ids.includes('crm_name'));
  q.answers.features = { crm: 'want' };
  ids = visibleQuestions(stage, q).map(x => x.id);
  assert.ok(ids.includes('crm_name'));
  q.answers.features = { crm: 'no' };
  ids = visibleQuestions(stage, q).map(x => x.id);
  assert.ok(!ids.includes('crm_name'));
});
await test('«Другое» как тип требует описания проекта', () => {
  const q = newQuestionnaire();
  q.answers.site_type = 'other';
  const stage = STAGES.find(s => s.id === 'type');
  const errs = validateStage(stage, q);
  assert.ok(errs.some(e => e.id === 'site_type_other'));
  q.answers.site_type_other = 'Портал для партнёров';
  assert.ok(!validateStage(stage, q).some(e => e.id === 'site_type_other'));
});

console.log('— Валидация и прогресс —');
await test('Контакты: имя, телефон и согласие обязательны', () => {
  const q = newQuestionnaire();
  q.answers.site_type = 'card';
  const stage = STAGES.find(s => s.id === 'final');
  const errIds = validateStage(stage, q).map(e => e.id);
  assert.ok(errIds.includes('contact_name'));
  assert.ok(errIds.includes('contact_phone'));
  assert.ok(errIds.includes('consent'));
  Object.assign(q.answers, { contact_name: 'Иван', contact_phone: '+7 900 000-00-00', consent: true });
  assert.equal(validateStage(stage, q).length, 0);
});
await test('Прогресс растёт при ответах', () => {
  const q = newQuestionnaire();
  q.answers.site_type = 'landing';
  const p1 = progress(q);
  q.answers.company_name = 'Тест';
  q.answers.goals = ['leads'];
  const p2 = progress(q);
  assert.ok(p2.answered === p1.answered + 2);
  assert.ok(p2.total > 30, 'вопросов должно быть много: ' + p2.total);
});

console.log('— Сводка —');
await test('Скрытые ответы неактивной ветки не попадают в сводку', () => {
  const q = newQuestionnaire();
  q.answers.site_type = 'shop';
  q.answers.shop_products_count = '1000+';
  q.answers.bk_services = 'Стрижка 500 руб';   // ответ из ветки записи
  q.answers.company_name = 'ООО Тест';
  // переключаем тип — ветка магазина и записи неактивны
  q.answers.site_type = 'portfolio';
  const text = summaryToText(q);
  assert.ok(!text.includes('1000'), 'ответ скрытой ветки магазина попал в сводку');
  assert.ok(!text.includes('Стрижка'), 'ответ скрытой ветки записи попал в сводку');
  assert.ok(text.includes('ООО Тест'));
  assert.ok(text.includes('Портфолио'));
});
await test('Пустые поля в сводке отмечены как «Не указано», ничего не придумано', () => {
  const q = newQuestionnaire();
  q.answers.site_type = 'card';
  const text = summaryToText(q);
  assert.ok(text.includes('Не указано'));
});
await test('«Пока не знаю» попадает в раздел «Что уточнить»', () => {
  const q = newQuestionnaire();
  q.answers.site_type = 'card';
  q.answers.sections = { blog: 'dk', home: 'must' };
  const sections = buildSummary(q);
  const clarify = sections.find(s => s.title.startsWith('18'));
  assert.ok(clarify, 'нет раздела 18');
  assert.ok(JSON.stringify(clarify).includes('Блог'));
});
await test('Матрица в сводке: обязательные и желательные разделы разделены', () => {
  const q = newQuestionnaire();
  q.answers.site_type = 'card';
  q.answers.sections = { home: 'must', reviews: 'want', blog: 'no' };
  const s = buildSummary(q).find(x => x.title.startsWith('7'));
  const must = s.items.find(i => i.label === 'Обязательные разделы');
  const want = s.items.find(i => i.label === 'Желательные разделы');
  assert.ok(must.value.includes('Главная') && !must.value.includes('Отзывы'));
  assert.ok(want.value.includes('Отзывы') && !want.value.includes('Блог'));
});

console.log('— Копирование итога —');
await test('Полный текст: все активные этапы, ответы, «Не указано», без скрытых веток', () => {
  const q = newQuestionnaire();
  q.answers = { site_type: 'portfolio', company_name: 'Студия Ёлка', goals: ['leads'], sections: { home: 'must' },
                shop_products_count: '1000+', consent: true };
  const t = fullReportText(q);
  assert.ok(t.includes('Студия Ёлка') && t.includes('Получение заявок') && t.includes('Главная — Обязательно'));
  assert.ok(t.includes('=== О КОМПАНИИ ===') && t.includes('=== ПОРТФОЛИО ==='));
  assert.ok(t.includes('Не указано'));
  assert.ok(!t.includes('1000+') && !t.includes('=== ИНТЕРНЕТ-МАГАЗИН'), 'скрытая ветка попала в текст');
});

console.log('— Формат обмена —');
await test('Экспорт → проверка → импорт без потерь', () => {
  const q = newQuestionnaire();
  q.answers = { site_type: 'shop', company_name: 'Сёмга и Ко', consent: true };
  q.fileRefs = [{ id: 'f1', qid: 'content_files', name: 'прайс.xlsx', type: 'app/x', size: 123 }];
  q.notes = [{ id: 'n1', text: 'Позвонить в среду', created_at: q.created_at }];
  const ex = buildExchange([q]);
  assert.equal(ex.format, EXCHANGE_FORMAT);
  assert.equal(ex.version, EXCHANGE_VERSION);
  const v = validateExchange(JSON.parse(JSON.stringify(ex)));
  assert.ok(v.ok, v.errors.join('; '));
  const back = fromExchange(v.data.questionnaires[0]);
  assert.equal(back.id, q.id);
  assert.equal(back.answers.company_name, 'Сёмга и Ко');
  assert.equal(back.fileRefs[0].name, 'прайс.xlsx');
  assert.equal(back.notes[0].text, 'Позвонить в среду');
});
await test('Чужой формат и будущая версия отклоняются с понятной ошибкой', () => {
  assert.ok(!validateExchange({ format: 'something.else', version: 1, questionnaires: [] }).ok);
  const v = validateExchange({ format: EXCHANGE_FORMAT, version: 99, questionnaires: [] });
  assert.ok(!v.ok && v.errors.join(' ').includes('новее'));
  assert.ok(!validateExchange({ format: EXCHANGE_FORMAT, version: 1, questionnaires: [{ answers: {} }] }).ok);
});

console.log('— ZIP —');
await test('ZIP: запись и чтение с кириллицей, целостность по CRC', async () => {
  const enc = new TextEncoder();
  const entries = [
    { name: 'data.json', data: enc.encode(JSON.stringify({ привет: 'мир' })) },
    { name: 'files/абв/прайс лист.txt', data: enc.encode('Содержимое файла, кириллица ёЁ') },
  ];
  const zip = createZip(entries);
  const back = await readZip(zip);
  assert.equal(back.length, 2);
  assert.equal(back[1].name, 'files/абв/прайс лист.txt');
  assert.equal(new TextDecoder().decode(back[1].data), 'Содержимое файла, кириллица ёЁ');
});
await test('ZIP: повреждение данных обнаруживается', async () => {
  const zip = createZip([{ name: 'a.txt', data: new TextEncoder().encode('hello world 123') }]);
  zip[35] ^= 0xFF; // портим байт внутри данных
  await assert.rejects(() => readZip(zip), /повреждён|не совпадает/i);
});
await test('crc32 эталон', () => {
  assert.equal(crc32(new TextEncoder().encode('123456789')), 0xCBF43926);
});

console.log('— Пароль без WebCrypto (iPhone по http) —');
await test('SHA-256 на JS совпадает с эталоном Node (в т.ч. пустая, 55/56/64/200 байт)', () => {
  for (const n of [0, 1, 55, 56, 63, 64, 65, 200]) {
    const m = new Uint8Array(n).map((_, i) => (i * 7 + 3) & 255);
    assert.equal(Buffer.from(sha256Js(m)).toString('hex'), nodeCrypto.createHash('sha256').update(m).digest('hex'), 'len ' + n);
  }
});
await test('PBKDF2 на JS идентичен node:crypto (короткий, кириллица, длинный пароль >64 байт)', () => {
  const salt = Uint8Array.from({ length: 16 }, (_, i) => i * 13);
  for (const pw of ['a', 'пароль-Ёж 123', 'x'.repeat(100)]) {
    const mine = Buffer.from(pbkdf2Sha256Js(new TextEncoder().encode(pw), salt, 5000)).toString('hex');
    const ref = nodeCrypto.pbkdf2Sync(pw, salt, 5000, 32, 'sha256').toString('hex');
    assert.equal(mine, ref, pw.slice(0, 8));
  }
});
await test('hash/verify: запись создана WebCrypto проверяется JS-вариантом и наоборот', async () => {
  const rec = await hashPassword('Секрет123', null, 20000);              // WebCrypto
  assert.ok(await verifyPassword('Секрет123', rec));
  const saved = globalThis.crypto.subtle;
  Object.defineProperty(globalThis.crypto, 'subtle', { value: undefined, configurable: true });
  try {
    assert.ok(await verifyPassword('Секрет123', rec), 'JS не принял хеш WebCrypto');
    assert.ok(!(await verifyPassword('неверный', rec)));
    const rec2 = await hashPassword('Другой', null, 20000);              // JS
    Object.defineProperty(globalThis.crypto, 'subtle', { value: saved, configurable: true });
    assert.ok(await verifyPassword('Другой', rec2), 'WebCrypto не принял хеш JS');
  } finally { Object.defineProperty(globalThis.crypto, 'subtle', { value: saved, configurable: true }); }
});
await test('160 000 итераций на JS укладываются в разумное время', () => {
  const t0 = Date.now();
  pbkdf2Sha256Js(new TextEncoder().encode('test123'), new Uint8Array(16), 160000);
  const ms = Date.now() - t0; console.log('     время:', ms, 'мс');
  assert.ok(ms < 4000);
});

console.log(`\nИтог: пройдено ${passed}, провалено ${failed}`);
process.exit(failed ? 1 : 0);
