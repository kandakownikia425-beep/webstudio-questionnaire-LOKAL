# server.py — локальный сервер WebStudio Questionnaire (только стандартная библиотека Python).
# Запуск: python server.py          — только этот компьютер (start.bat)
#         python server.py --lan    — доступ с iPhone по Wi-Fi (start-iphone.bat)
# Сервер отдаёт статические файлы приложения. Все данные хранятся в браузере (IndexedDB).
import http.server
import socketserver
import webbrowser
import os
import sys
import socket

PORT = 8750
LAN = '--lan' in sys.argv


def lan_ip():
    """IP компьютера в локальной сети (для открытия с iPhone)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('10.255.255.255', 1))
        return s.getsockname()[0]
    except Exception:
        return None
    finally:
        s.close()

os.chdir(os.path.dirname(os.path.abspath(__file__)))


class Handler(http.server.SimpleHTTPRequestHandler):
    extensions_map = {
        **http.server.SimpleHTTPRequestHandler.extensions_map,
        '.js': 'application/javascript; charset=utf-8',
        '.css': 'text/css; charset=utf-8',
        '.html': 'text/html; charset=utf-8',
        '.webmanifest': 'application/manifest+json; charset=utf-8',
        '.json': 'application/json; charset=utf-8',
        '.svg': 'image/svg+xml',
    }

    def end_headers(self):
        # приложение обновляется мгновенно, без устаревшего кэша
        self.send_header('Cache-Control', 'no-cache')
        super().end_headers()

    def log_message(self, fmt, *args):
        pass  # не шумим в консоли и не пишем данные в логи


def main():
    port = PORT
    for attempt in range(10):
        try:
            socketserver.TCPServer.allow_reuse_address = True
            with socketserver.TCPServer(('0.0.0.0' if LAN else '127.0.0.1', port), Handler) as httpd:
                url = f'http://localhost:{port}/'
                ip = lan_ip() if LAN else None
                print('=' * 52)
                print('  WebStudio Questionnaire запущен')
                print(f'  Откройте в браузере: {url}')
                if LAN:
                    if ip:
                        print()
                        print('  ДЛЯ iPHONE (в той же Wi-Fi сети) откройте в Safari:')
                        print(f'     http://{ip}:{port}/')
                        print('  Если не открывается — разрешите доступ в брандмауэре Windows')
                        print('  (при первом запуске нажмите «Разрешить» для частных сетей).')
                        print()
                    else:
                        print('  Не удалось определить IP — смотрите «IPv4-адрес» в ipconfig.')
                print('  Для остановки закройте это окно или нажмите Ctrl+C')
                print('=' * 52)
                try:
                    webbrowser.open(url)
                except Exception:
                    pass
                httpd.serve_forever()
                return
        except OSError:
            port += 1  # порт занят — пробуем следующий
    print('Не удалось найти свободный порт. Закройте другие копии приложения.')
    sys.exit(1)


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('\nСервер остановлен.')
